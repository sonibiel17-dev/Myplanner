# Meu Planner

Aplicativo web responsivo com estética rosa queimado, bege e branco. Funciona em celular e computador.

## Módulos
- Visão geral e tarefas
- Rotina e agenda (criar, concluir, buscar e filtrar tarefas)
- Finanças (entradas, despesas, saldo e categorias)
- Negócios (projetos, prazos, notas e status)
- Estudos (matérias, provas, status e notas)
- Família e casa (tarefas, eventos e categorias)
- Metas e hábitos (marcação diária de hábitos e progresso de metas)

## Como abrir para testar
Extraia o ZIP e abra `index.html` em um navegador moderno. A interface e o armazenamento local funcionam para teste; alguns navegadores restringem recursos de PWA quando abertos diretamente como `file://`.

## Como instalar como aplicativo (PWA)
Para instalar corretamente, publique os arquivos em um endereço HTTPS:
1. Crie uma conta no GitHub e um repositório, por exemplo `meu-planner`.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. No GitHub, vá a **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**, escolha `main` e `/ (root)`, e salve.
5. Aguarde a publicação e abra o endereço HTTPS mostrado pelo GitHub Pages.

### Android
Abra o endereço HTTPS no Chrome. Use o menu ⋮ e escolha **Instalar app** ou **Adicionar à tela inicial**.

### iPhone / iPad
Abra o endereço HTTPS no Safari. Toque em **Compartilhar** → **Adicionar à Tela de Início**.

### Computador
No Chrome ou Edge, abra o endereço publicado e use o ícone de instalação na barra de endereços, quando disponível, ou o menu do navegador.

## Armazenamento e privacidade
- Os dados são guardados no `localStorage` do navegador, neste dispositivo e neste perfil.
- Não há conta, sincronização na nuvem ou envio automático dos dados.
- Limpar os dados do navegador pode apagar seus registros. Evite usar navegação anônima.
- Para exportar uma cópia de segurança em JSON, use `Ctrl+Shift+E` (Windows/Linux) ou `Cmd+Shift+E` (Mac) dentro do app.
- Para manter seus dados entre celular e computador será necessária uma futura versão com sincronização em nuvem.

## Observações técnicas
- O `manifest.json` define o app instalável.
- `sw.js` fornece cache offline depois da primeira visita em uma hospedagem HTTPS.
- Se alterar arquivos depois de publicar, talvez seja necessário atualizar o cache do service worker (a versão está definida em `sw.js`).

## Próximos aprimoramentos sugeridos
1. Importar backup JSON dentro do app.
2. Edição de itens já cadastrados.
3. Agenda mensal em formato de calendário.
4. Notificações e lembretes (dependem das permissões e do navegador).
5. Sincronização segura entre dispositivos.
